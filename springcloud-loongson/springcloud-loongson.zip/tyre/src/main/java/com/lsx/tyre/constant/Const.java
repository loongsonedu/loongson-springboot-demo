package com.lsx.tyre.constant;

/**
 * 静态常量类
 */
public class Const {

    /**
     * 减号
     */
    public static final String PREFIX_MINUS = "-";

    /**
     * 0
     */
    public static final String ZERO = "0";
}
