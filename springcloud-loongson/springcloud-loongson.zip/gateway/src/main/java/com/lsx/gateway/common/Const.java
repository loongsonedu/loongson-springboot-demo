package com.lsx.gateway.common;

/**
 * @Description: 静态变量
 * @Author: ldc
 * @Date: 2018-10-19
 **/
public class Const {

    // token 过期时间
    public static final long TOKEN_EXPIRE_SECONDS = 3600;

}
